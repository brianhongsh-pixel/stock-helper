package app.stockhelper

import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.Charset
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * The phone fetches stock data itself (an app is not blocked the way a browser page is),
 * so no PC server or Google Apps Script is needed. Exposed to JavaScript as window.StockNative.
 */
class Bridge(private val a: MainActivity) {
    private val pool = Executors.newFixedThreadPool(8)
    private val allowed = setOf(
        "query1.finance.yahoo.com", "query2.finance.yahoo.com", "ac.stock.naver.com", "m.stock.naver.com",
        "api.stock.naver.com", "polling.finance.naver.com", "fchart.stock.naver.com"
    )
    private val cache = object : LinkedHashMap<String, Pair<Long, String>>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Pair<Long, String>>?) = size > 200
    }

    @JavascriptInterface fun version(): String = BuildConfig.VERSION_NAME

    /** Fetch several URLs in parallel; answers [{ok, status, body}] through window.__stockDone(id, json). */
    @JavascriptInterface
    fun fetchMany(id: String, urlsJson: String) {
        Thread {
            val out = JSONArray()
            try {
                val arr = JSONArray(urlsJson)
                val urls = (0 until minOf(arr.length(), 60)).map { arr.optString(it) }
                val futures = urls.map { u -> pool.submit(Callable { fetchOne(u) }) }
                for (f in futures) {
                    out.put(try { f.get(40, TimeUnit.SECONDS) } catch (e: Exception) { result(false, 0, null) })
                }
            } catch (e: Throwable) { }
            a.js("window.__stockDone(${JSONObject.quote(id)}, ${JSONObject.quote(out.toString())})")
        }.start()
    }

    private fun result(ok: Boolean, status: Int, body: String?) =
        JSONObject().put("ok", ok).put("status", status).put("body", body ?: JSONObject.NULL)

    private fun fetchOne(u: String): JSONObject {
        val url = try { URL(u) } catch (e: Exception) { return result(false, 400, null) }
        if (url.protocol != "https" || url.host !in allowed) return result(false, 403, null)
        synchronized(cache) {
            cache[u]?.let { (t, body) -> if (System.currentTimeMillis() - t < 120_000) return result(true, 200, body) }
        }
        var conn: HttpURLConnection? = null
        return try {
            conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 12000; readTimeout = 20000; instanceFollowRedirects = true
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0 Mobile Safari/537.36")
                setRequestProperty("Accept", "application/json,text/plain,*/*")
                setRequestProperty("Accept-Language", "ko-KR,ko;q=0.9,en;q=0.8")
                if (url.host.endsWith("naver.com")) setRequestProperty("Referer", "https://m.stock.naver.com/")
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val bytes = stream?.use { s -> ByteArrayOutputStream().also { s.copyTo(it) }.toByteArray() } ?: ByteArray(0)
            if (code !in 200..299) return result(false, code, null)
            val body = String(bytes, charsetOf(conn.contentType, bytes))
            synchronized(cache) { cache[u] = Pair(System.currentTimeMillis(), body) }
            result(true, code, body)
        } catch (e: Exception) {
            result(false, 0, null)
        } finally {
            conn?.disconnect()
        }
    }

    /** Naver's chart feed is EUC-KR; use the header, then an XML declaration, then UTF-8. */
    private fun charsetOf(contentType: String?, bytes: ByteArray): Charset {
        val fromHeader = contentType?.let { Regex("charset=([^;\\s]+)", RegexOption.IGNORE_CASE).find(it)?.groupValues?.get(1)?.trim('"', '\'') }
        val fromXml = if (fromHeader == null) {
            val head = String(bytes, 0, minOf(bytes.size, 200), Charsets.ISO_8859_1)
            Regex("encoding=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE).find(head)?.groupValues?.get(1)
        } else null
        return try { Charset.forName(fromHeader ?: fromXml ?: "UTF-8") } catch (e: Exception) { Charsets.UTF_8 }
    }
}
