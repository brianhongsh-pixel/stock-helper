plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// The web app (../../web) is bundled into the APK as assets/www.
val webAssetsRoot = layout.buildDirectory.dir("generated/webassets").get().asFile
val copyWeb by tasks.registering(Sync::class) {
    from(rootProject.file("../web")) { exclude("sw.js", "icon.ico") }
    into(File(webAssetsRoot, "www"))
}

val runNumber = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
val keystoreFile = file("release.keystore")

android {
    namespace = "app.stockhelper"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.stockhelper"
        minSdk = 24
        targetSdk = 34
        versionCode = runNumber
        versionName = "1.2.$runNumber"
    }

    signingConfigs {
        create("release") {
            if (keystoreFile.exists()) {
                storeFile = keystoreFile
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS") ?: "coupon"
                keyPassword = System.getenv("KEY_PASSWORD") ?: System.getenv("KEYSTORE_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = if (keystoreFile.exists()) signingConfigs.getByName("release") else signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures { buildConfig = true }
    sourceSets["main"].assets.srcDir(webAssetsRoot)

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

tasks.named("preBuild") { dependsOn(copyWeb) }

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("androidx.webkit:webkit:1.11.0")
}
